function v=matversion
[v d]=version;
v=str2num(datestr(datenum(d),'yyyy'));
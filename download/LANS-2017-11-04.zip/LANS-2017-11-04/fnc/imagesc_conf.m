function a = imagesc_conf(IM, mi, ma, conf, colmap)
% display image with the SIC correction

cmap = get_colormap(colmap);

if prod(conf(:))==1
    % when no correction for the SI counts is requested
    a=imagesc(IM,[mi ma]);
    colormap(cmap);
else
    % first, cut out the darkest colors from the colormap
    cmap = cmap(6:size(cmap,1),:);
    % apply intensity correction to the image displayed in the selected hue
    as=(IM-mi)/(ma - mi);
    a1=ind2rgb(uint8(as*64),cmap);
    a1(:,:,1)=a1(:,:,1).*conf;
    a1(:,:,2)=a1(:,:,2).*conf;
    a1(:,:,3)=a1(:,:,3).*conf;
    a=image(a1);
end;

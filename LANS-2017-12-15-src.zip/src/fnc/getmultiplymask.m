function R=getmultiplymask(i13,i12,Mask)
% calculate i13*i12 and apply Mask

s=sprintf('*** This is getmultiplymask ***');
%disp(s);

R=i13.*i12;

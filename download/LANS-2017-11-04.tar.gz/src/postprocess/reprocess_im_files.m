function reprocess_im_files(fnames,ratios,base_dir,cells_file)

